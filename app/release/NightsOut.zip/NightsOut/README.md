# NightsOut
App to track BAC while drinking and lists what you drank on each night
